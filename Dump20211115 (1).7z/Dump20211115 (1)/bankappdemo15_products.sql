-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: bankappdemo15
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `picture_url` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8kn1epvpofqp5fkwxset0i8t5` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,' Features: Any Resident Individual - Single Accounts, Two or more individuals in Joint Accounts, Illiterate Persons, Visually Impaired persons, Purdanasheen Ladies, Minors, Associations, Clubs, Societies, etc.','General Saving Account','ecommerce-angular-main\\src\\assets\\images\\BankLogo.jpg',NULL,1),(9,'A current account can be opened by individuals, public and private companies, proprietors, associations, trusts etc.','Current Account','https://e-gulfbank.imgix.net/en/media/current-account-15415_v20_tcm27-15415.jpg?fm=jpg&q=65&dpr=1&fit=crop&crop=edges&w=800&h=320',NULL,1),(3,'Home loans, also known as mortgages, use the borrower\'s home for collateral. This home can be a single-family house up to a four-unit property, as well as a condominium or cooperative unit. ','Home Loan','https://www.financegab.com/wp-content/uploads/2019/09/home-loan-from-bank.jpg',NULL,2),(4,'What It Means A car loan (also known as an automobile loan, or auto loan) is a sum of money a consumer borrows in order to purchase a car. Generally speaking a loan is an amount of money that is lent to an individual, a business, or another entity.','Auto Loan','https://th.bing.com/th/id/R.4b5526e281deb23ecfe716dc884281af?rik=pwxXBCyPxGtqLA&riu=http%3a%2f%2fwww.myayan.com%2fassets%2fimages%2fart%2ftop-car-loan-banks-in-dubai.png&ehk=BQZ41ZLoOW7%2b154%2bQirgoVHji6JGn9FKLjhxmGHGpSQ%3d&risl=&pid=ImgRaw&r=0',NULL,2),(5,'Personal loan is a short to medium term unsecured loan granted to an individual. It is commonly used to meet such financial needs as debt consolidation, wedding expenses, unexpected medical costs, home renovation and others.','Personal Loan','https://1.bp.blogspot.com/-7S-jGSRvpN0/XSEicbFMccI/AAAAAAABpwM/ZHFNU4Az9KU_aV4MW7qFIFvaew-51eLJwCLcBGAs/s1600/Personal-Loan.jpg',NULL,2),(6,'Jet Airways American Express® Platinum Credit Card. American Express PAYBACK® Credit Card . Next. American Express® Platinum Card. American Express ® Platinum Card. American Express ® Platinum Card. Compare Card. Card Type. . ','american express platinum credit card','https://i2.wp.com/thepointsguy.com/wp-content/uploads/2017/03/IMG_7190.jpg?fit=2000%2C1333px&ssl=1',NULL,3),(7,'Your American Express ® Gold Card is now grander with bonus rewards and cashbacks. Introducing monthly Card fee at just ₹375 1 and get 2X value every month.','american express gold credit card','https://th.bing.com/th/id/OIP.FXLsrxMQcWxAHKFidX6FGgHaE2?pid=ImgDet&rs=1',NULL,3),(8,'The City Bank American Express® Platinum Credit Card This is a world that is built for your passions – the passion to explore the unexplored, the passion to savor the delectable, the passion to experience the finest things in life.','city alo american express platinum credit card','https://th.bing.com/th/id/OIP.BlApTZEut6ZiPro8Ecij_wHaHY?pid=ImgDet&rs=1',NULL,3);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-15 22:05:27
